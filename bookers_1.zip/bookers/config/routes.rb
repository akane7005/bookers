Rails.application.routes.draw do
  get '/' => 'homes#top'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  get 'books/index' => 'books#index'
  post 'book' => 'books#create'
  get 'book/:id' => 'books#show', as: 'bookshow'
  get 'book/:id/edit' => 'books#edit', as: 'bookedit'
  patch 'book/:id' => 'books#update', as: 'bookupdate'
  delete 'book/:id' => 'books#destroy', as: 'bookdestroy'
end
